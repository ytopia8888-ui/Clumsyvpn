# Clumsy VPN v6

Native Android project for building with GitHub Actions.

Included in this build:
- VPN permission/service test interface (does not route internet traffic)
- Engine profile selector: LocalVpn, PcapDroid, ToyShark, AsyncToyShark
- Client/server packet test profile controls
- JSON configuration import/export using Android document picker
- Floating ON/OFF control

Important: the named third-party engines are profile labels only and are not bundled or integrated. Client/server packet settings are saved as configuration and do not shape live traffic. The current VPN service intentionally has no routes and does not forward packets.
