plugins { id("com.android.application") }

android {
    namespace = "com.clumsyvpn.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.clumsyvpn.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}


dependencies {
    implementation("androidx.activity:activity:1.9.3")
}

// Align all Kotlin standard-library artifacts to one version to avoid duplicate classes.
configurations.configureEach {
    resolutionStrategy.eachDependency {
        if (requested.group == "org.jetbrains.kotlin" &&
            requested.name.startsWith("kotlin-stdlib")) {
            useVersion("1.8.22")
        }
    }
}
