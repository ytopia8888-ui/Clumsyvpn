# Clumsy VPN v7

Native Android project intended for building with GitHub Actions.

Changes in v7:
- Fixed disconnect action by sending ACTION_STOP to the foreground VPN service and closing the TUN descriptor before stopping.
- UI now reports CONNECTING until the service state is confirmed rather than immediately claiming connection.
- Preserves the dark control-panel layout, engine profile selector, client/server test profile sliders, and JSON import/export.

Important limitations:
- The VPN currently creates a local TUN interface without routes. It does not tunnel internet traffic.
- PcapDroid, ToyShark, and AsyncToyShark are selectable labels only; external integrations are not bundled.
- Packet delay, jitter, frequency and drop values are saved as profile settings and are not applied to live traffic.
