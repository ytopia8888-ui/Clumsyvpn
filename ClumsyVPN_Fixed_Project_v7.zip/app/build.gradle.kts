plugins { id("com.android.application") }

android {
    namespace = "com.clumsyvpn.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.clumsyvpn.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "1.3"
    }
}


dependencies {
    implementation("androidx.activity:activity:1.9.3")
}

// Keep transitive Kotlin standard-library artifacts on the same version.
configurations.configureEach {
    resolutionStrategy.force(
        "org.jetbrains.kotlin:kotlin-stdlib:1.8.22",
        "org.jetbrains.kotlin:kotlin-stdlib-jdk7:1.8.22",
        "org.jetbrains.kotlin:kotlin-stdlib-jdk8:1.8.22"
    )
}
