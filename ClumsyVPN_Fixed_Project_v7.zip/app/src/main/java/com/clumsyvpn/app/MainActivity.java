package com.clumsyvpn.app;

import android.app.Activity;
import androidx.activity.ComponentActivity;
import android.content.Intent;
import android.net.VpnService;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class MainActivity extends ComponentActivity {
    private static final String PREFS = "clumsy_settings";
    private TextView status, toggle;
    private boolean waitingForOverlayPermission = false;
    private Spinner engineSpinner;
    private boolean connected = false;
    private final String[] engines = {"LocalVpn", "PcapDroid", "ToyShark", "AsyncToyShark"};
    private final ActivityResultLauncher<Intent> vpnPermission = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK) startVpn();
            else Toast.makeText(this, "VPN permission was not granted", Toast.LENGTH_LONG).show();
        });
    private final ActivityResultLauncher<String> exportConfig = registerForActivityResult(
        new ActivityResultContracts.CreateDocument("application/json"), uri -> {
            if (uri != null) writeConfig(uri);
        });
    private final ActivityResultLauncher<String[]> importConfig = registerForActivityResult(
        new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri != null) readConfig(uri);
        });

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12, 14, 23));
        getWindow().setNavigationBarColor(Color.rgb(12, 14, 23));
        buildUi();
    }
    @Override protected void onResume() {
        super.onResume();
        if (status != null) {
            refreshStatus();
            if (waitingForOverlayPermission && Settings.canDrawOverlays(this)) {
                waitingForOverlayPermission = false;
                Toast.makeText(this, "Разрешение выдано. Нажми CONNECT VPN ещё раз.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(28));
        root.setBackgroundColor(Color.rgb(12, 14, 23));
        scroll.addView(root);
        root.addView(text("NETWORK LAB  /  ANDROID", 11, 0xFF9299B1, true), matchWrap());
        TextView logo = text("CLUMSY", 34, 0xFFFF5364, true); logo.setPadding(0, dp(7), 0, 0); root.addView(logo, matchWrap());
        TextView subtitle = text("VPN CONTROL CENTER · V7", 12, 0xFFC0C5D6, true); subtitle.setPadding(0, 0, 0, dp(22)); root.addView(subtitle, matchWrap());

        LinearLayout statusCard = card();
        statusCard.addView(text("CONNECTION", 11, 0xFF9299B1, true), matchWrap());
        status = text("●  VPN DISCONNECTED", 17, Color.WHITE, true); status.setPadding(0, dp(13), 0, dp(4)); statusCard.addView(status, matchWrap());
        statusCard.addView(text("Floating control toggles Clumsy separately from the VPN service.", 12, 0xFFB5BBD0, false), matchWrap());
        toggle = text("CONNECT VPN", 15, Color.WHITE, true); toggle.setGravity(Gravity.CENTER); toggle.setPadding(0, dp(15), 0, dp(15));
        toggle.setBackground(bg(0xFFFF5364, 16)); toggle.setOnClickListener(v -> requestVpn());
        LinearLayout.LayoutParams tp = matchWrap(); tp.topMargin = dp(18); statusCard.addView(toggle, tp); root.addView(statusCard, matchWrap());

        LinearLayout engineCard = card();
        engineCard.addView(text("VPN ENGINE PROFILE", 14, Color.WHITE, true), matchWrap());
        TextView engineInfo = text("Choose a profile. External engines are not bundled or launched automatically; each needs a verified integration.", 12, 0xFFB5BBD0, false);
        engineInfo.setPadding(0, dp(6), 0, dp(10)); engineCard.addView(engineInfo, matchWrap());
        engineSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, engines);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        engineSpinner.setAdapter(adapter);
        String savedEngine = prefs().getString("engine", "LocalVpn");
        for (int i = 0; i < engines.length; i++) if (engines[i].equals(savedEngine)) engineSpinner.setSelection(i);
        engineSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) { prefs().edit().putString("engine", engines[position]).apply(); }
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });
        engineCard.addView(engineSpinner, matchWrap()); root.addView(engineCard, matchWrap());

        LinearLayout clientCard = card();
        clientCard.addView(text("CLIENT PACKET PROFILE", 14, Color.WHITE, true), matchWrap());
        TextView clientInfo = text("Test-profile values for a controlled lab connection. Values are saved to the configuration; they do not yet shape live game traffic.", 12, 0xFFB5BBD0, false);
        clientInfo.setPadding(0, dp(5), 0, dp(8)); clientCard.addView(clientInfo, matchWrap());
        addSlider(clientCard, "Client packet frequency", "client_freq", 1, 1000, " pkt/s");
        addSlider(clientCard, "Packet delay", "latency", 0, 2000, " ms");
        addSlider(clientCard, "Packet jitter", "jitter", 0, 1000, " ms");
        addSlider(clientCard, "Client packet drop", "client_drop", 0, 100, "%");
        root.addView(clientCard, matchWrap());

        LinearLayout serverCard = card();
        serverCard.addView(text("SERVER PACKET PROFILE", 14, Color.WHITE, true), matchWrap());
        TextView serverInfo = text("Server-side values are configuration presets only. They take effect only when connected to a compatible server you control.", 12, 0xFFB5BBD0, false);
        serverInfo.setPadding(0, dp(5), 0, dp(8)); serverCard.addView(serverInfo, matchWrap());
        addSlider(serverCard, "Server packet frequency", "server_freq", 1, 1000, " pkt/s");
        addSlider(serverCard, "Server packet drop", "server_drop", 0, 100, "%");
        root.addView(serverCard, matchWrap());

        LinearLayout configCard = card();
        configCard.addView(text("CONFIGURATION", 14, Color.WHITE, true), matchWrap());
        TextView configInfo = text("Export/download a JSON profile or import one from your phone.", 12, 0xFFB5BBD0, false);
        configInfo.setPadding(0, dp(5), 0, dp(12)); configCard.addView(configInfo, matchWrap());
        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button export = button("EXPORT / DOWNLOAD"); export.setOnClickListener(v -> exportConfig.launch("clumsy-profile.json"));
        Button imp = button("IMPORT JSON"); imp.setOnClickListener(v -> importConfig.launch(new String[]{"application/json", "text/*", "application/octet-stream"}));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(48), 1); bp.rightMargin = dp(6); buttons.addView(export, bp);
        LinearLayout.LayoutParams bp2 = new LinearLayout.LayoutParams(0, dp(48), 1); bp2.leftMargin = dp(6); buttons.addView(imp, bp2);
        configCard.addView(buttons, matchWrap()); root.addView(configCard, matchWrap());

        LinearLayout floatCard = card(); floatCard.addView(text("FLOATING CONTROL", 13, 0xFFFF7885, true), matchWrap());
        TextView note = text("Allow display over other apps when prompted. The movable CLUMSY ON/OFF pill controls the test toggle without disconnecting the VPN service.", 12, 0xFFC0C5D6, false);
        note.setPadding(0, dp(8), 0, 0); floatCard.addView(note, matchWrap()); root.addView(floatCard, matchWrap());
        TextView disclaimer = text("Compatibility note: PcapDroid, ToyShark and AsyncToyShark are selectable labels only in this build. Their engines are not included. Packet shaping is not implemented for live traffic.", 11, 0xFF81889F, false);
        disclaimer.setPadding(dp(4), dp(8), dp(4), 0); root.addView(disclaimer, matchWrap());
        setContentView(scroll);
    }

    private void addSlider(LinearLayout parent, String label, String key, int min, int max, String suffix) {
        int value = prefs().getInt(key, key.equals("client_freq") || key.equals("server_freq") ? 100 : 0);
        value = Math.max(min, Math.min(max, value));
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(0, dp(7), 0, dp(4));
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(label, 13, 0xFFE5E8F2, true); TextView val = text(value + suffix, 13, 0xFFFF7885, true); val.setGravity(Gravity.END);
        top.addView(name, new LinearLayout.LayoutParams(0, dp(24), 1)); top.addView(val, wrapWrap()); row.addView(top, matchWrap());
        SeekBar seek = new SeekBar(this); seek.setMax(max - min); seek.setProgress(value - min);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFFF5364)); seek.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFFF7885));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean fromUser) { int actual = p + min; val.setText(actual + suffix); if (fromUser) prefs().edit().putInt(key, actual).apply(); }
            public void onStartTrackingTouch(SeekBar b) {} public void onStopTrackingTouch(SeekBar b) {}
        });
        row.addView(seek, matchWrap()); parent.addView(row, matchWrap());
    }

    private void requestVpn() {
        if (connected || ClumsyVpnService.isRunning) {
            Intent stop = new Intent(this, ClumsyVpnService.class);
            stop.setAction(ClumsyVpnService.ACTION_STOP);
            try {
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(stop); else startService(stop);
            } catch (Exception e) {
                stopService(new Intent(this, ClumsyVpnService.class));
            }
            connected = false;
            refreshStatus();
            Toast.makeText(this, "Отключение VPN…", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            waitingForOverlayPermission = true;
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            Toast.makeText(this, "Разреши показ поверх других приложений и вернись сюда", Toast.LENGTH_LONG).show(); return;
        }
        Intent prepare = VpnService.prepare(this); if (prepare != null) vpnPermission.launch(prepare); else startVpn();
    }
    private void startVpn() {
        Intent service = new Intent(this, ClumsyVpnService.class); service.setAction(ClumsyVpnService.ACTION_START);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
            // The service confirms its state asynchronously; do not claim it is connected before establish() succeeds.
            status.setText("●  CONNECTING…");
            toggle.setText("CANCEL / DISCONNECT");
            toggle.setBackground(bg(0xFF34394B, 16));
            status.postDelayed(this::refreshStatus, 700);
        } catch (Exception e) { connected = false; refreshStatus(); Toast.makeText(this, "Could not start service: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private void refreshStatus() {
        if (status == null) return; connected = ClumsyVpnService.isRunning;
        status.setText(connected ? "●  VPN SERVICE RUNNING" : "●  VPN DISCONNECTED"); status.setTextColor(connected ? 0xFF71E3A0 : Color.WHITE);
        toggle.setText(connected ? "DISCONNECT VPN" : "CONNECT VPN"); toggle.setBackground(bg(connected ? 0xFF34394B : 0xFFFF5364, 16));
    }
    private void writeConfig(Uri uri) {
        try {
            JSONObject j = new JSONObject(); j.put("format", "clumsy-vpn-profile"); j.put("version", 1);
            j.put("engine", prefs().getString("engine", "LocalVpn"));
            String[] keys = {"client_freq", "latency", "jitter", "client_drop", "server_freq", "server_drop"};
            for (String key : keys) j.put(key, prefs().getInt(key, key.equals("client_freq") || key.equals("server_freq") ? 100 : 0));
            try (OutputStream out = getContentResolver().openOutputStream(uri)) { if (out == null) throw new Exception("Cannot open destination"); out.write(j.toString(2).getBytes(StandardCharsets.UTF_8)); }
            Toast.makeText(this, "Configuration exported", Toast.LENGTH_LONG).show();
        } catch (Exception e) { Toast.makeText(this, "Export failed: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private void readConfig(Uri uri) {
        try {
            StringBuilder s = new StringBuilder();
            try (InputStream in = getContentResolver().openInputStream(uri); BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) { String line; while ((line = r.readLine()) != null) s.append(line); }
            JSONObject j = new JSONObject(s.toString()); if (!"clumsy-vpn-profile".equals(j.optString("format"))) throw new Exception("Not a Clumsy VPN profile");
            android.content.SharedPreferences.Editor e = prefs().edit();
            String engine = j.optString("engine", "LocalVpn"); boolean valid = false; for (String candidate : engines) if (candidate.equals(engine)) valid = true;
            e.putString("engine", valid ? engine : "LocalVpn");
            String[] keys = {"client_freq", "latency", "jitter", "client_drop", "server_freq", "server_drop"};
            int[] defaults = {100, 0, 0, 0, 100, 0}; int[] mins = {1, 0, 0, 0, 1, 0}; int[] maxs = {1000, 2000, 1000, 100, 1000, 100};
            for (int i = 0; i < keys.length; i++) e.putInt(keys[i], Math.max(mins[i], Math.min(maxs[i], j.optInt(keys[i], defaults[i]))));
            e.apply(); Toast.makeText(this, "Configuration imported. Reopen screen to refresh sliders.", Toast.LENGTH_LONG).show();
            recreate();
        } catch (Exception e) { Toast.makeText(this, "Import failed: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private android.content.SharedPreferences prefs() { return getSharedPreferences(PREFS, MODE_PRIVATE); }
    private Button button(String label) { Button b = new Button(this); b.setText(label); b.setTextSize(11); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackground(bg(0xFF30364A, 12)); return b; }
    private LinearLayout card() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(18), dp(17), dp(18), dp(18)); l.setBackground(bg(0xFF1B1F2D, 20)); LinearLayout.LayoutParams p = matchWrap(); p.bottomMargin = dp(14); l.setLayoutParams(p); return l; }
    private TextView text(String s, int size, int color, boolean bold) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t; }
    private GradientDrawable bg(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams wrapWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
