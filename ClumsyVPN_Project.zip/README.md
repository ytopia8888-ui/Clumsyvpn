# Clumsy VPN (permission test build)

Native Android project for building with GitHub Actions. The Connect button calls `VpnService.prepare()` and starts a foreground VPN service after consent. The service creates a local TUN interface without adding routes, so it does not capture or disrupt internet traffic.

**Important:** latency and packet-loss simulation / packet forwarding are not implemented in this build. Do not treat the connected status as a full VPN tunnel.

Build: `gradle assembleDebug`
