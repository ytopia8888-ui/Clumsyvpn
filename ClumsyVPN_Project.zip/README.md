# Clumsy VPN — Android prototype

Android Studio/Gradle source project. Designed for Android 6+ and builds a debug APK with GitHub Actions.

## Current functionality
- Dark UI with red accents
- Enable/disable demo button
- Latency and packet-loss sliders (UI state only)

## Important
This is currently a **UI prototype**, not a functioning VPN or packet shaper. The toggle and sliders do not intercept or alter network traffic. A real implementation requires a correctly implemented Android `VpnService` and packet-processing engine; do not advertise it as changing real latency/loss until that is implemented and tested.

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK support, or use the included GitHub Actions workflow.
