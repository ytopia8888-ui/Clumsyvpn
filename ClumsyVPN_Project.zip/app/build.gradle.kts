plugins { id("com.android.application") }

android {
    namespace = "com.clumsyvpn.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.clumsyvpn.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "1.1"
    }
}


dependencies {
    implementation("androidx.activity:activity:1.9.3")
}
