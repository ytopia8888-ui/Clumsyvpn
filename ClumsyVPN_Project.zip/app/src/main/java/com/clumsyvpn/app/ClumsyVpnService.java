package com.clumsyvpn.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.content.pm.ServiceInfo;

public class ClumsyVpnService extends VpnService {
    public static final String ACTION_START = "com.clumsyvpn.app.START";
    private static final String CHANNEL = "clumsy_vpn_status";
    private ParcelFileDescriptor vpnInterface;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        createChannel();
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1001, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1001, notification);
        if (intent != null && ACTION_START.equals(intent.getAction())) {
            try {
                if (vpnInterface == null) {
                    vpnInterface = new Builder().setSession("Clumsy VPN local test").addAddress("10.10.0.2", 32).establish();
                    // No routes are added: this test build intentionally does not capture or interrupt internet traffic.
                    if (vpnInterface == null) stopSelf();
                }
            } catch (Exception e) { stopSelf(); }
        }
        return START_NOT_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Clumsy VPN status", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, 0, open, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        return b.setContentTitle("Clumsy VPN").setContentText("Local test interface is running")
            .setSmallIcon(android.R.drawable.stat_sys_warning).setContentIntent(pending).setOngoing(true).build();
    }
    @Override public void onDestroy() {
        if (vpnInterface != null) { try { vpnInterface.close(); } catch (Exception ignored) {} vpnInterface = null; }
        super.onDestroy();
    }
    @Override public void onRevoke() {
        if (vpnInterface != null) { try { vpnInterface.close(); } catch (Exception ignored) {} vpnInterface = null; }
        stopSelf();
    }
}
