package com.clumsyvpn.app;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16,16,20), panel = Color.rgb(29,29,36), red = Color.rgb(255,59,69), white = Color.WHITE, muted = Color.rgb(165,165,178);
    private TextView status, toggle;
    private boolean enabled = false;
    private int latency = 100, loss = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(26),dp(22),dp(20)); root.setBackgroundColor(bg);
        TextView brand = text("CLUMSY VPN", 13, red, true); brand.setLetterSpacing(.12f); root.addView(brand);
        TextView title = text("Network Lab", 30, white, true); LinearLayout.LayoutParams tp = params(-1,-2); tp.topMargin=dp(8); root.addView(title,tp);
        TextView subtitle = text("Тестирование задержки соединения", 14, muted, false); root.addView(subtitle);
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(18),dp(18),dp(18),dp(18)); card.setBackground(round(panel,18));
        LinearLayout.LayoutParams cp=params(-1,-2); cp.topMargin=dp(24); root.addView(card,cp);
        status=text("●  ОТКЛЮЧЕНО",14,muted,true); card.addView(status);
        toggle=new TextView(this); toggle.setText("ВЫКЛ"); toggle.setTextColor(white); toggle.setTextSize(18); toggle.setTypeface(null,Typeface.BOLD); toggle.setGravity(Gravity.CENTER); toggle.setBackground(round(red,100));
        LinearLayout.LayoutParams bp=params(-1,dp(58)); bp.topMargin=dp(18); card.addView(toggle,bp); toggle.setOnClickListener(v -> flip());
        TextView hint=text("Демо-интерфейс: реальное изменение трафика пока не подключено.",12,muted,false); LinearLayout.LayoutParams hp=params(-1,-2); hp.topMargin=dp(12); card.addView(hint,hp);
        LinearLayout settings=new LinearLayout(this); settings.setOrientation(LinearLayout.VERTICAL); settings.setPadding(dp(18),dp(18),dp(18),dp(18)); settings.setBackground(round(panel,18)); LinearLayout.LayoutParams sp=params(-1,-2); sp.topMargin=dp(16); root.addView(settings,sp);
        settings.addView(text("НАСТРОЙКИ ТЕСТА",12,red,true));
        settings.addView(text("Задержка",16,white,true),topMargin(16)); TextView lv=text(""+latency+" мс",14,muted,false); settings.addView(lv);
        SeekBar latencyBar=new SeekBar(this); latencyBar.setMax(1000); latencyBar.setProgress(latency); latencyBar.setProgressTintList(android.content.res.ColorStateList.valueOf(red)); settings.addView(latencyBar); latencyBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar b,int p,boolean u){latency=p;lv.setText(p+" мс");} public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){} });
        settings.addView(text("Потеря пакетов",16,white,true),topMargin(16)); TextView lossLabel=text(loss+" %",14,muted,false); settings.addView(lossLabel);
        SeekBar lossBar=new SeekBar(this); lossBar.setMax(100); lossBar.setProgress(0); lossBar.setProgressTintList(android.content.res.ColorStateList.valueOf(red)); settings.addView(lossBar); lossBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){ public void onProgressChanged(SeekBar b,int p,boolean u){loss=p;lossLabel.setText(p+" %");} public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){} });
        TextView footer=text("Clumsy VPN • Android",12,muted,false); footer.setGravity(Gravity.CENTER); LinearLayout.LayoutParams fp=params(-1,-2); fp.topMargin=dp(20); root.addView(footer,fp);
        setContentView(root);
    }
    private void flip(){ enabled=!enabled; status.setText(enabled?"●  ДЕМО ВКЛЮЧЕНО":"●  ОТКЛЮЧЕНО"); status.setTextColor(enabled?red:muted); toggle.setText(enabled?"ВКЛЮЧЕНО":"ВЫКЛ"); toggle.setBackground(round(enabled?Color.rgb(50,150,95):red,100)); }
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private GradientDrawable round(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
    private LinearLayout.LayoutParams params(int w,int h){return new LinearLayout.LayoutParams(w,h);}
    private LinearLayout.LayoutParams topMargin(int m){LinearLayout.LayoutParams p=params(-1,-2);p.topMargin=dp(m);return p;}
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
}
