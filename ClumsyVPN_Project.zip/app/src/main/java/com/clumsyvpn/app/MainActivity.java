package com.clumsyvpn.app;

import android.app.Activity;
import androidx.activity.ComponentActivity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

public class MainActivity extends ComponentActivity {
    private TextView status;
    private Button toggle;
    private boolean requested = false;
    private final ActivityResultLauncher<Intent> vpnPermission = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK) startVpn();
            else Toast.makeText(this, "VPN permission was not granted", Toast.LENGTH_LONG).show();
        });

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16, 17, 23));
        getWindow().setNavigationBarColor(Color.rgb(16, 17, 23));
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(24), dp(38), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(16, 17, 23));
        TextView logo = new TextView(this);
        logo.setText("CLUMSY VPN"); logo.setTextColor(Color.rgb(255, 70, 85)); logo.setTextSize(28);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD); root.addView(logo, matchWrap());
        TextView subtitle = new TextView(this);
        subtitle.setText("NETWORK TEST TOOL"); subtitle.setTextColor(Color.LTGRAY); subtitle.setTextSize(12);
        subtitle.setPadding(0, dp(8), 0, dp(36)); root.addView(subtitle, matchWrap());
        status = new TextView(this); status.setText("Status: disconnected"); status.setTextColor(Color.WHITE);
        status.setTextSize(17); status.setGravity(Gravity.CENTER); status.setPadding(dp(12), dp(20), dp(12), dp(20)); root.addView(status, matchWrap());
        toggle = new Button(this); toggle.setText("CONNECT"); toggle.setTextSize(16); toggle.setOnClickListener(v -> requestVpn());
        LinearLayout.LayoutParams bp = matchWrap(); bp.topMargin = dp(24); root.addView(toggle, bp);
        TextView note = new TextView(this);
        note.setText("This build tests Android VPN permission and starts a local test interface only. It does not yet forward internet traffic or apply latency / packet loss.");
        note.setTextColor(Color.rgb(180, 183, 194)); note.setTextSize(13); note.setGravity(Gravity.CENTER);
        note.setPadding(dp(4), dp(30), dp(4), dp(4)); root.addView(note, matchWrap());
        setContentView(root);
    }

    private void requestVpn() {
        if (requested) {
            stopService(new Intent(this, ClumsyVpnService.class)); requested = false;
            status.setText("Status: disconnected"); toggle.setText("CONNECT"); return;
        }
        Intent prepareIntent = VpnService.prepare(this);
        if (prepareIntent != null) vpnPermission.launch(prepareIntent); else startVpn();
    }

    private void startVpn() {
        Intent service = new Intent(this, ClumsyVpnService.class);
        service.setAction(ClumsyVpnService.ACTION_START);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
            requested = true; status.setText("Status: test interface started"); toggle.setText("DISCONNECT");
        } catch (Exception e) {
            status.setText("Could not start VPN service");
            Toast.makeText(this, e.getClass().getSimpleName() + ": " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
