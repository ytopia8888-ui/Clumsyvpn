package com.clumsyvpn.app;

import android.app.Activity;
import androidx.activity.ComponentActivity;
import android.content.Intent;
import android.net.VpnService;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;

public class MainActivity extends ComponentActivity {
    private static final String PREFS = "clumsy_settings";
    private TextView status, toggle;
    private boolean connected = false;
    private final ActivityResultLauncher<Intent> vpnPermission = registerForActivityResult(
        new ActivityResultContracts.StartActivityForResult(), result -> {
            if (result.getResultCode() == Activity.RESULT_OK) startVpn();
            else Toast.makeText(this, "VPN permission was not granted", Toast.LENGTH_LONG).show();
        });

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(12, 14, 23));
        getWindow().setNavigationBarColor(Color.rgb(12, 14, 23));
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        if (status != null) refreshStatus();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(28));
        root.setBackgroundColor(Color.rgb(12, 14, 23));
        scroll.addView(root);

        TextView eyebrow = text("NETWORK LAB  /  ANDROID", 11, 0xFF9299B1, true);
        root.addView(eyebrow, matchWrap());
        TextView logo = text("CLUMSY", 34, 0xFFFF5364, true);
        logo.setPadding(0, dp(7), 0, 0); root.addView(logo, matchWrap());
        TextView subtitle = text("VPN CONTROL CENTER", 12, 0xFFC0C5D6, true);
        subtitle.setPadding(0, 0, 0, dp(22)); root.addView(subtitle, matchWrap());

        LinearLayout statusCard = card();
        TextView section = text("CONNECTION", 11, 0xFF9299B1, true);
        statusCard.addView(section, matchWrap());
        status = text("●  VPN DISCONNECTED", 17, Color.WHITE, true);
        status.setPadding(0, dp(13), 0, dp(4)); statusCard.addView(status, matchWrap());
        TextView small = text("The floating switch controls Clumsy separately.", 12, 0xFFB5BBD0, false);
        statusCard.addView(small, matchWrap());
        toggle = text("CONNECT VPN", 15, Color.WHITE, true);
        toggle.setGravity(Gravity.CENTER); toggle.setPadding(0, dp(15), 0, dp(15));
        toggle.setBackground(bg(0xFFFF5364, 16)); toggle.setOnClickListener(v -> requestVpn());
        LinearLayout.LayoutParams tp = matchWrap(); tp.topMargin = dp(18); statusCard.addView(toggle, tp);
        root.addView(statusCard, matchWrap());

        LinearLayout settings = card();
        TextView title = text("PACKET EFFECTS", 14, Color.WHITE, true);
        settings.addView(title, matchWrap());
        TextView info = text("Adjust test parameters. These values are saved for the control UI.", 12, 0xFFB5BBD0, false);
        info.setPadding(0, dp(5), 0, dp(12)); settings.addView(info, matchWrap());
        addSlider(settings, "Latency", "latency", 0, 1000, " ms");
        addSlider(settings, "Packet loss", "loss", 0, 100, "%");
        addSlider(settings, "Jitter", "jitter", 0, 500, " ms");
        root.addView(settings, matchWrap());

        LinearLayout noteCard = card();
        TextView noteTitle = text("FLOATING CONTROL", 13, 0xFFFF7885, true);
        noteCard.addView(noteTitle, matchWrap());
        TextView note = text("After connecting, allow “Display over other apps”. A movable red pill will appear over other apps. Tap it to switch Clumsy ON/OFF without disconnecting the VPN service.", 12, 0xFFC0C5D6, false);
        note.setPadding(0, dp(8), 0, 0); noteCard.addView(note, matchWrap());
        root.addView(noteCard, matchWrap());

        TextView disclaimer = text("NOTE: this build provides VPN permission + local test interface and floating controls. Real packet forwarding and latency/loss injection are not implemented yet.", 11, 0xFF81889F, false);
        disclaimer.setPadding(dp(4), dp(16), dp(4), 0); root.addView(disclaimer, matchWrap());
        setContentView(scroll);
    }

    private void addSlider(LinearLayout parent, String label, String key, int min, int max, String suffix) {
        int value = getSharedPreferences(PREFS, MODE_PRIVATE).getInt(key, 0);
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(0, dp(8), 0, dp(5));
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView name = text(label, 13, 0xFFE5E8F2, true);
        TextView val = text(value + suffix, 13, 0xFFFF7885, true); val.setGravity(Gravity.END);
        top.addView(name, new LinearLayout.LayoutParams(0, dp(24), 1)); top.addView(val, wrapWrap()); row.addView(top, matchWrap());
        SeekBar seek = new SeekBar(this); seek.setMax(max - min); seek.setProgress(value - min);
        seek.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFFF5364));
        seek.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFFF7885));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                int actual = p + min; val.setText(actual + suffix);
                if (fromUser) getSharedPreferences(PREFS, MODE_PRIVATE).edit().putInt(key, actual).apply();
            }
            public void onStartTrackingTouch(SeekBar b) {}
            public void onStopTrackingTouch(SeekBar b) {}
        });
        row.addView(seek, matchWrap()); parent.addView(row, matchWrap());
    }

    private void requestVpn() {
        if (connected) {
            stopService(new Intent(this, ClumsyVpnService.class));
            connected = false;
            status.setText("●  VPN DISCONNECTED"); status.setTextColor(Color.WHITE);
            toggle.setText("CONNECT VPN"); toggle.setBackground(bg(0xFFFF5364, 16));
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            Intent overlay = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(overlay);
            Toast.makeText(this, "Allow display over other apps, then tap CONNECT VPN again", Toast.LENGTH_LONG).show();
            return;
        }
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) vpnPermission.launch(prepare); else startVpn();
    }

    private void startVpn() {
        Intent service = new Intent(this, ClumsyVpnService.class); service.setAction(ClumsyVpnService.ACTION_START);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
            connected = true; refreshStatus();
        } catch (Exception e) { Toast.makeText(this, "Could not start service: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private void refreshStatus() {
        if (status == null) return;
        connected = ClumsyVpnService.isRunning;
        status.setText(connected ? "●  VPN SERVICE RUNNING" : "●  VPN DISCONNECTED");
        status.setTextColor(connected ? 0xFF71E3A0 : Color.WHITE);
        toggle.setText(connected ? "DISCONNECT VPN" : "CONNECT VPN");
        toggle.setBackground(bg(connected ? 0xFF34394B : 0xFFFF5364, 16));
    }
    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(18), dp(17), dp(18), dp(18));
        l.setBackground(bg(0xFF1B1F2D, 20)); LinearLayout.LayoutParams p = matchWrap(); p.bottomMargin = dp(14); l.setLayoutParams(p); return l;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private GradientDrawable bg(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }
    private LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams wrapWrap() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
