# Clumsy VPN — native Android UI prototype

- Native dark/red control panel with latency, packet-loss, and jitter controls saved locally.
- Android VPN consent flow and foreground service with a local TUN interface.
- Draggable floating `CLUMSY ON/OFF` control. Switching it OFF does not disconnect the VPN service; use `DISCONNECT VPN` in the app to stop the service.
- The sliders and floating switch currently control the app's settings/state only. This prototype does **not** forward packets or apply real latency/loss/jitter to internet traffic. The TUN interface intentionally has no routes so normal internet traffic is not captured or interrupted.

Build in GitHub Actions with `gradle assembleDebug`.
