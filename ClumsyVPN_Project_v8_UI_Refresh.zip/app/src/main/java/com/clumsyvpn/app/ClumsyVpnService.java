package com.clumsyvpn.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.content.pm.ServiceInfo;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.graphics.drawable.GradientDrawable;
import android.widget.TextView;

public class ClumsyVpnService extends VpnService {
    public static final String ACTION_START = "com.clumsyvpn.app.START";
    public static final String ACTION_STOP = "com.clumsyvpn.app.STOP";
    private static final String CHANNEL = "clumsy_vpn_status";
    private static final String PREFS = "clumsy_settings";
    public static volatile boolean isRunning = false;
    private ParcelFileDescriptor vpnInterface;
    private WindowManager windowManager;
    private TextView floatingButton;
    private boolean clumsyEnabled = true;
    private WindowManager.LayoutParams overlayParams;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            isRunning = false;
            removeFloatingButton();
            if (vpnInterface != null) {
                try { vpnInterface.close(); } catch (Exception ignored) {}
                vpnInterface = null;
            }
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        createChannel();
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) startForeground(1001, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(1001, notification);
        if (intent != null && ACTION_START.equals(intent.getAction())) {
            try {
                if (vpnInterface == null) {
                    vpnInterface = new Builder().setSession("Clumsy VPN test interface").addAddress("10.10.0.2", 32).establish();
                    // Intentionally no routes: this safe test interface does not capture or disrupt internet traffic.
                }
                if (vpnInterface != null) {
                    isRunning = true;
                    clumsyEnabled = true;
                    getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("clumsy_enabled", true).apply();
                    showFloatingButton();
                } else stopSelf();
            } catch (Exception e) { stopSelf(); }
        }
        return START_NOT_STICKY;
    }

    private void showFloatingButton() {
        if (floatingButton != null) return;
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        floatingButton = new TextView(this);
        floatingButton.setText("CLUMSY  ON"); floatingButton.setTextColor(Color.WHITE); floatingButton.setTextSize(12);
        floatingButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD); floatingButton.setGravity(Gravity.CENTER);
        floatingButton.setPadding(dp(16), dp(12), dp(16), dp(12)); floatingButton.setElevation(dp(8));
        floatingButton.setBackground(pill(0xFFFF5364));
        overlayParams = new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        overlayParams.gravity = Gravity.TOP | Gravity.END; overlayParams.x = dp(14); overlayParams.y = dp(180);
        floatingButton.setOnTouchListener(new View.OnTouchListener() {
            private float downX, downY; private int startX, startY; private boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) { downX = e.getRawX(); downY = e.getRawY(); startX = overlayParams.x; startY = overlayParams.y; moved = false; return true; }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    int dx = (int)(e.getRawX() - downX), dy = (int)(e.getRawY() - downY);
                    if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                    if (moved) { overlayParams.x = Math.max(0, startX - dx); overlayParams.y = Math.max(0, startY + dy); try { windowManager.updateViewLayout(floatingButton, overlayParams); } catch (Exception ignored) {} }
                    return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) { if (!moved) toggleClumsy(); return true; }
                return true;
            }
        });
        try { windowManager.addView(floatingButton, overlayParams); } catch (Exception e) { floatingButton = null; }
    }

    private void toggleClumsy() {
        clumsyEnabled = !clumsyEnabled;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putBoolean("clumsy_enabled", clumsyEnabled).apply();
        if (floatingButton != null) {
            floatingButton.setText(clumsyEnabled ? "CLUMSY  ON" : "CLUMSY  OFF");
            floatingButton.setBackground(pill(clumsyEnabled ? 0xFFFF5364 : 0xFF444A5E));
        }
        NotificationManager nm = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        nm.notify(1001, buildNotification());
    }

    private GradientDrawable pill(int color) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(28)); d.setStroke(dp(1), 0x55FFFFFF); return d; }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Clumsy VPN status", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT; if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pending = PendingIntent.getActivity(this, 0, open, flags);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        String state = clumsyEnabled ? "Clumsy controls ON · VPN service running" : "Clumsy controls OFF · VPN service still running";
        return b.setContentTitle("Clumsy VPN").setContentText(state).setSmallIcon(android.R.drawable.stat_sys_warning).setContentIntent(pending).setOngoing(true).build();
    }
    private void removeFloatingButton() {
        if (floatingButton != null && windowManager != null) { try { windowManager.removeView(floatingButton); } catch (Exception ignored) {} }
        floatingButton = null;
    }
    @Override public void onDestroy() {
        isRunning = false; removeFloatingButton();
        if (vpnInterface != null) { try { vpnInterface.close(); } catch (Exception ignored) {} vpnInterface = null; }
        super.onDestroy();
    }
    @Override public void onRevoke() {
        isRunning = false; removeFloatingButton();
        if (vpnInterface != null) { try { vpnInterface.close(); } catch (Exception ignored) {} vpnInterface = null; }
        stopSelf();
    }
}
