package com.clumsyvpn.app;

import android.app.Activity;
import androidx.activity.ComponentActivity;
import android.content.Intent;
import android.net.VpnService;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends ComponentActivity {
    private static final String PREFS="clumsy_settings";
    private static final int BG=0xFF292A30, PANEL=0xFF202126, BORDER=0xFF484953, BLUE=0xFF1478D4, WHITE=0xFFF4F4F7, MUTED=0xFF858590;
    private TextView status, mainToggle;
    private boolean connected=false, waitingOverlay=false;
    private String page="home";
    private final String[] engines={"LocalVpn","PcapDroid","ToyShark","AsyncToyShark"};
    private final ActivityResultLauncher<Intent> vpnPermission=registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), r->{if(r.getResultCode()==Activity.RESULT_OK) startVpn(); else toast("VPN-разрешение не выдано");});
    private final ActivityResultLauncher<String> exportConfig=registerForActivityResult(new ActivityResultContracts.CreateDocument("application/json"), u->{if(u!=null) writeConfig(u);});
    private final ActivityResultLauncher<String[]> importConfig=registerForActivityResult(new ActivityResultContracts.OpenDocument(), u->{if(u!=null) readConfig(u);});

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(PANEL);getWindow().setNavigationBarColor(PANEL);showPage("home");}
    @Override protected void onResume(){super.onResume();if(waitingOverlay&&Settings.canDrawOverlays(this)){waitingOverlay=false;toast("Разрешение получено");} if(status!=null)refreshStatus();}

    private void showPage(String p){
        page=p; LinearLayout shell=new LinearLayout(this);shell.setOrientation(LinearLayout.VERTICAL);shell.setBackgroundColor(BG);
        FrameLayout content=new FrameLayout(this); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,0,1);shell.addView(content,cp);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(20),dp(18),dp(20),dp(24));sc.addView(body);content.addView(sc);
        if(p.equals("home")) buildHome(body); else if(p.equals("configs")) buildConfigs(body); else buildSettings(body);
        LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setBackgroundColor(PANEL);nav.setPadding(dp(8),dp(8),dp(8),dp(6));
        nav.addView(navItem("☷","Конфиги","configs"),new LinearLayout.LayoutParams(0,dp(62),1));
        nav.addView(navItem("⌂","Главная","home"),new LinearLayout.LayoutParams(0,dp(62),1));
        nav.addView(navItem("☰","Настройки","settings"),new LinearLayout.LayoutParams(0,dp(62),1));shell.addView(nav);setContentView(shell);
    }
    private View navItem(String icon,String label,String target){LinearLayout l=new LinearLayout(this);l.setGravity(Gravity.CENTER);l.setOrientation(LinearLayout.VERTICAL);TextView i=txt(icon,25,target.equals(page)?WHITE:MUTED,true);TextView t=txt(label,12,target.equals(page)?WHITE:MUTED,false);l.addView(i);l.addView(t);l.setOnClickListener(v->showPage(target));return l;}
    private void buildHome(LinearLayout b){
        b.addView(txt("Главная",30,WHITE,false),wrap()); LinearLayout card=card();card.addView(txt("Подпишитесь на нас!",20,WHITE,false),wrap());TextView sub=txt("Подпишитесь на наш Telegram",15,MUTED,false);sub.setPadding(0,dp(8),0,0);card.addView(sub,wrap());b.addView(card,wrap());
        LinearLayout news=card();news.setBackground(shape(BG,BORDER,18));news.addView(txt("Что нового?",19,WHITE,false),wrap());news.addView(txt("Состояние VPN, профили и импорт конфигураций",14,MUTED,false),wrap());b.addView(news,wrap());
        LinearLayout cfg=card();cfg.setBackground(shape(BG,BORDER,18));cfg.addView(txt("Установлен конфиг",18,WHITE,false),wrap());cfg.addView(txt(prefs().getString("config_name","Default profile"),14,MUTED,false),wrap());Button edit=outline("Изменить");edit.setOnClickListener(v->showPage("configs"));cfg.addView(edit,marginWrap(0,dp(12),0,0));b.addView(cfg,wrap());
        LinearLayout connection=card();connection.addView(txt("Подключение",18,WHITE,true),wrap());status=txt("● VPN отключён",16,WHITE,true);status.setPadding(0,dp(12),0,dp(8));connection.addView(status,wrap());connection.addView(txt("Тестовый локальный интерфейс. Интернет-трафик через него не маршрутизируется.",12,MUTED,false),wrap());
        mainToggle=txt("▶   ПОДКЛЮЧИТЬ VPN",17,Color.WHITE,true);mainToggle.setGravity(Gravity.CENTER);mainToggle.setPadding(0,dp(17),0,dp(17));mainToggle.setBackground(shape(0xFFB90000,0xFFB90000,18));mainToggle.setOnClickListener(v->requestVpn());connection.addView(marginView(mainToggle,0,dp(16),0,0),wrap());b.addView(connection,wrap());
        LinearLayout profiles=card();profiles.addView(txt("Активный профиль",16,WHITE,true),wrap());profiles.addView(txt("Движок: "+prefs().getString("engine","LocalVpn"),14,MUTED,false),wrap());Button settings=outline("Открыть настройки");settings.setOnClickListener(v->showPage("settings"));profiles.addView(marginView(settings,0,dp(12),0,0),wrap());b.addView(profiles,wrap());refreshStatus();
    }
    private void buildConfigs(LinearLayout b){
        b.addView(txt("Конфиги",30,WHITE,false),wrap());TextView tabs=txt("Пользовательские                         Приобретённые",15,WHITE,false);tabs.setPadding(dp(8),dp(16),0,dp(16));b.addView(tabs,wrap());
        LinearLayout c=card();c.addView(txt(prefs().getString("config_name","Default profile"),19,WHITE,true),wrap());c.addView(txt("Локальная конфигурация · JSON",14,MUTED,false),wrap());
        Button installed=outline("Установлено");installed.setEnabled(false);c.addView(marginView(installed,0,dp(14),0,dp(8)),wrap());
        LinearLayout row=new LinearLayout(this);Button exp=blueButton("Экспорт");Button imp=blueButton("Импорт");row.addView(exp,new LinearLayout.LayoutParams(0,dp(50),1));row.addView(imp,new LinearLayout.LayoutParams(0,dp(50),1));exp.setOnClickListener(v->exportConfig.launch("clumsy-profile.json"));imp.setOnClickListener(v->importConfig.launch(new String[]{"application/json","text/*","application/octet-stream"}));c.addView(row,wrap());
        Button edit=outline("Редактировать параметры");edit.setOnClickListener(v->showPage("settings"));c.addView(marginView(edit,0,dp(10),0,0),wrap());b.addView(c,wrap());
        Button add=blueButton("+  Создать конфиг");add.setOnClickListener(v->{prefs().edit().putString("config_name","New profile").apply();showPage("settings");});b.addView(marginView(add,0,dp(14),0,0),wrap());
        b.addView(txt("Конфигурации сохраняют настройки интерфейса. Они не являются серверными ключами и не создают удалённый VPN-туннель.",12,MUTED,false),marginWrap(0,dp(14),0,0));
    }
    private void buildSettings(LinearLayout b){
        b.addView(txt("Настройки",30,WHITE,false),wrap());
        LinearLayout c=card();c.addView(txt("VPN-движок",18,WHITE,true),wrap());c.addView(txt("Выбор профиля. Внешние проекты не вшиты автоматически.",12,MUTED,false),marginWrap(0,dp(5),0,dp(8)));
        Spinner sp=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,engines);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);sp.setAdapter(a);String saved=prefs().getString("engine","LocalVpn");for(int i=0;i<engines.length;i++)if(engines[i].equals(saved))sp.setSelection(i);sp.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>x,View v,int pos,long id){prefs().edit().putString("engine",engines[pos]).apply();}public void onNothingSelected(android.widget.AdapterView<?>x){}});c.addView(sp,wrap());b.addView(c,wrap());
        LinearLayout target=card();target.addView(txt("Плавающее окно",18,WHITE,true),wrap());Button overlay=outline("Разрешение отображения поверх приложений");overlay.setOnClickListener(v->{if(!Settings.canDrawOverlays(this)){waitingOverlay=true;startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));}else toast("Разрешение уже выдано");});target.addView(marginView(overlay,0,dp(12),0,0),wrap());b.addView(target,wrap());
        LinearLayout packet=card();packet.addView(txt("Пакеты клиента · тестовые параметры",17,WHITE,true),wrap());packet.addView(txt("Настройки сохраняются для локального тестирования; они не влияют на трафик онлайн-игры.",12,MUTED,false),marginWrap(0,dp(5),0,dp(8)));
        slider(packet,"Частота пакетов","client_freq",1,1000," пак/с",100);slider(packet,"Задержка","latency",0,2000," мс",0);slider(packet,"Джиттер","jitter",0,1000," мс",0);slider(packet,"Потери в тесте","client_drop",0,100," %",0);b.addView(packet,wrap());
        LinearLayout server=card();server.addView(txt("Параметры сервера",17,WHITE,true),wrap());slider(server,"Частота","server_freq",1,1000," пак/с",100);slider(server,"Потери в тесте","server_drop",0,100," %",0);b.addView(server,wrap());
        Button save=blueButton("Сохранить настройки");save.setOnClickListener(v->{prefs().edit().putString("config_name","Custom profile").apply();toast("Настройки сохранены");});b.addView(marginView(save,0,dp(6),0,dp(12)),wrap());
    }
    private void slider(LinearLayout parent,String label,String key,int min,int max,String suffix,int def){int value=Math.max(min,Math.min(max,prefs().getInt(key,def)));LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(0,dp(8),0,dp(4));LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);top.addView(txt(label,14,WHITE,false),new LinearLayout.LayoutParams(0,dp(26),1));TextView val=txt(value+suffix,14,WHITE,true);top.addView(val);row.addView(top,wrap());SeekBar seek=new SeekBar(this);seek.setMax(max-min);seek.setProgress(value-min);seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean u){int n=p+min;val.setText(n+suffix);if(u)prefs().edit().putInt(key,n).apply();}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});row.addView(seek,wrap());parent.addView(row,wrap());}
    private void requestVpn(){if(connected||ClumsyVpnService.isRunning){Intent i=new Intent(this,ClumsyVpnService.class);i.setAction(ClumsyVpnService.ACTION_STOP);try{startService(i);}catch(Exception e){stopService(i);}connected=false;refreshStatus();toast("Отключение…");new android.os.Handler().postDelayed(this::refreshStatus,350);return;}if(!Settings.canDrawOverlays(this)){waitingOverlay=true;startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));toast("Разреши плавающее окно и вернись");return;}Intent prep=VpnService.prepare(this);if(prep!=null)vpnPermission.launch(prep);else startVpn();}
    private void startVpn(){Intent i=new Intent(this,ClumsyVpnService.class);i.setAction(ClumsyVpnService.ACTION_START);try{if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);if(status!=null)status.setText("● Подключение…");new android.os.Handler().postDelayed(this::refreshStatus,700);}catch(Exception e){toast("Не удалось запустить службу: "+e.getMessage());refreshStatus();}}
    private void refreshStatus(){if(status==null||mainToggle==null)return;connected=ClumsyVpnService.isRunning;status.setText(connected?"● Служба запущена (тестовый режим)":"● VPN отключён");status.setTextColor(connected?0xFF70D6A5:WHITE);mainToggle.setText(connected?"■   ОТКЛЮЧИТЬ VPN":"▶   ПОДКЛЮЧИТЬ VPN");mainToggle.setBackground(shape(connected?0xFF454650:0xFFB90000,connected?BORDER:0xFFB90000,18));}
    private void writeConfig(Uri uri){try{JSONObject j=new JSONObject();j.put("format","clumsy-vpn-profile");j.put("version",2);j.put("name",prefs().getString("config_name","Default profile"));j.put("engine",prefs().getString("engine","LocalVpn"));String[] keys={"client_freq","latency","jitter","client_drop","server_freq","server_drop"};for(String k:keys)j.put(k,prefs().getInt(k,k.endsWith("freq")?100:0));try(OutputStream o=getContentResolver().openOutputStream(uri)){if(o==null)throw new IOException("Файл недоступен");o.write(j.toString(2).getBytes(StandardCharsets.UTF_8));}toast("Конфиг экспортирован");}catch(Exception e){toast("Ошибка экспорта: "+e.getMessage());}}
    private void readConfig(Uri uri){try{StringBuilder s=new StringBuilder();try(InputStream in=getContentResolver().openInputStream(uri);BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String line;while((line=r.readLine())!=null)s.append(line);}JSONObject j=new JSONObject(s.toString());if(!"clumsy-vpn-profile".equals(j.optString("format")))throw new Exception("Неверный формат");android.content.SharedPreferences.Editor e=prefs().edit();String en=j.optString("engine","LocalVpn");boolean ok=false;for(String x:engines)if(x.equals(en))ok=true;e.putString("engine",ok?en:"LocalVpn").putString("config_name",j.optString("name","Imported profile"));String[] keys={"client_freq","latency","jitter","client_drop","server_freq","server_drop"};int[] def={100,0,0,0,100,0},min={1,0,0,0,1,0},max={1000,2000,1000,100,1000,100};for(int i=0;i<keys.length;i++)e.putInt(keys[i],Math.max(min[i],Math.min(max[i],j.optInt(keys[i],def[i]))));e.apply();toast("Конфиг импортирован");showPage("configs");}catch(Exception e){toast("Ошибка импорта: "+e.getMessage());}}
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(18),dp(17),dp(18),dp(18));l.setBackground(shape(PANEL,PANEL,18));LinearLayout.LayoutParams p=wrap();p.bottomMargin=dp(14);l.setLayoutParams(p);return l;}
    private TextView txt(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable shape(int color,int stroke,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));d.setStroke(dp(1),stroke);return d;}
    private Button outline(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(WHITE);b.setBackground(shape(BG,BORDER,16));return b;}
    private Button blueButton(String s){Button b=outline(s);b.setBackground(shape(BLUE,BLUE,14));return b;}
    private View marginView(View v,int l,int t,int r,int b){LinearLayout wrap=new LinearLayout(this);wrap.setPadding(l,t,r,b);wrap.addView(v,new LinearLayout.LayoutParams(-1,-2));return wrap;}
    private LinearLayout.LayoutParams marginWrap(int l,int t,int r,int b){LinearLayout.LayoutParams p=wrap();p.setMargins(l,t,r,b);return p;}
    private LinearLayout.LayoutParams wrap(){return new LinearLayout.LayoutParams(-1,-2);}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private android.content.SharedPreferences prefs(){return getSharedPreferences(PREFS,MODE_PRIVATE);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
