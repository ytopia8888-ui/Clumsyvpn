# Clumsy VPN v8 UI refresh

This Android project has a redesigned three-tab interface inspired by the screenshots:
- Home dashboard with connection status and config card
- Configs screen with import/export
- Settings screen with engine profile selector and packet-test sliders

Build from the repository root with:
`gradle assembleDebug`

Important limitations:
- The engine names LocalVpn, PcapDroid, ToyShark, and AsyncToyShark are profile labels only; third-party engines are not bundled or launched.
- The VPN service creates a local test TUN interface without default routes. It does not route general internet traffic.
- Packet frequency, delay, jitter, and loss sliders are saved test-profile values and do not shape live traffic.
- Do not use packet manipulation to disrupt other players or services.
